/**
 * 提交新的修改申请
 * Run: node test-new-modification.js
 */

import axios from 'axios';

const API_BASE = 'http://localhost:3002/api';

async function submitNewModification() {
  try {
    console.log('📝 提交新的修改申请\n');
    
    // 1. 用户登录（使用存在的用户）
    console.log('步骤1: 尝试用户登录...');
    
    // 先尝试用admin账号（因为我们知道这个账号可以登录）
    const loginResponse = await axios.post(`${API_BASE}/auth/login`, {
      email: 'admin@example.com',
      password: 'admin123456'
    });
    
    const token = loginResponse.data.token;
    console.log('✅ 登录成功\n');
    
    // 2. 提交修改申请
    const orderNo = 'ORD1757839240567870';
    console.log(`步骤2: 为订单 ${orderNo} 提交新的修改申请`);
    
    const modificationData = {
      receiptData: {
        account: '新游戏账号2024',
        password: '新密码NewPass2024',
        server: '美国服务器',
        remark: '请优先处理，账号信息已更新'
      },
      reason: '之前填写的账号密码有误，现已更正为最新的账号信息'
    };
    
    console.log('修改申请内容:');
    console.log('  原因:', modificationData.reason);
    console.log('  新数据:', JSON.stringify(modificationData.receiptData, null, 2));
    
    try {
      const response = await axios.post(
        `${API_BASE}/order/receipts/${orderNo}/modify`,
        modificationData,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      console.log('\n✅ 修改申请提交成功!');
      console.log('响应:', response.data);
      
    } catch (error) {
      if (error.response?.status === 403) {
        console.log('\n⚠️  当前用户不是订单所有者');
        console.log('这个订单可能属于其他用户，无法提交修改申请');
      } else if (error.response?.status === 400) {
        console.log('\n⚠️  无法提交修改申请:');
        console.log(error.response.data.message);
      } else {
        throw error;
      }
    }
    
    // 3. 验证修改申请状态
    console.log('\n步骤3: 验证修改申请状态');
    
    const verifyResponse = await axios.get(
      `${API_BASE}/order/admin/receipts/${orderNo}`,
      {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      }
    );
    
    if (verifyResponse.data.data && verifyResponse.data.data.receipts) {
      const receipt = verifyResponse.data.data.receipts[0];
      if (receipt.notes) {
        const notes = JSON.parse(receipt.notes);
        if (notes.modificationRequest) {
          console.log('\n📋 当前修改申请状态:');
          console.log('  状态:', notes.modificationRequest.status);
          console.log('  原因:', notes.modificationRequest.reason);
          
          if (notes.modificationRequest.status === 'pending') {
            console.log('\n✅ 修改申请处于待审核状态！');
            console.log('🎯 现在管理员应该能在订单详情中看到"通过"和"拒绝"按钮了');
          } else {
            console.log('\n❌ 修改申请状态不是 pending:', notes.modificationRequest.status);
          }
        }
      }
    }
    
  } catch (error) {
    console.error('\n❌ 错误:', error.response?.data || error.message);
  }
}

submitNewModification();