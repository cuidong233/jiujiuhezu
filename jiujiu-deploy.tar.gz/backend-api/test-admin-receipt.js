/**
 * Test admin receipt viewing functionality
 * Run: node test-admin-receipt.js
 */

import axios from 'axios';

const API_BASE = 'http://localhost:3002/api';

async function testAdminReceiptView() {
  try {
    console.log('Testing admin receipt viewing...');
    
    // 1. Login as admin user
    const adminLoginResponse = await axios.post(`${API_BASE}/auth/login`, {
      email: 'admin@example.com',  // You may need to use an actual admin email
      password: 'admin123456'
    });
    
    const adminToken = adminLoginResponse.data.token;
    console.log('✅ Admin login successful');
    
    // 2. Get receipt information for an order
    const orderNo = 'ORD1757839240567870';
    
    console.log('Fetching receipt info for order:', orderNo);
    
    const receiptResponse = await axios.get(
      `${API_BASE}/order/admin/receipts/${orderNo}`,
      {
        headers: {
          'Authorization': `Bearer ${adminToken}`
        }
      }
    );
    
    console.log('\n📋 Receipt Information:');
    console.log('Status:', receiptResponse.data.code);
    
    if (receiptResponse.data.data && receiptResponse.data.data.receipts) {
      const receipts = receiptResponse.data.data.receipts;
      console.log('Number of receipts:', receipts.length);
      
      receipts.forEach((receipt, index) => {
        console.log(`\n--- Receipt ${index + 1} ---`);
        console.log('ID:', receipt.id);
        console.log('Order ID:', receipt.orderId);
        console.log('Receipt Fields:', receipt.receiptFields);
        console.log('Receipt Data:', receipt.receiptData);
        console.log('Notes:', receipt.notes);
        
        // Check for modification request
        if (receipt.notes) {
          try {
            const notes = JSON.parse(receipt.notes);
            if (notes.modificationRequest) {
              console.log('\n⚠️  MODIFICATION REQUEST FOUND:');
              console.log('Reason:', notes.modificationRequest.reason);
              console.log('New Data:', notes.modificationRequest.newData);
              console.log('Status:', notes.modificationRequest.status);
              console.log('Submitted At:', notes.modificationRequest.submittedAt);
            }
          } catch (e) {
            // Notes might not be JSON
          }
        }
      });
    } else {
      console.log('No receipts found for this order');
    }
    
    // 3. Test order list to see if proxy recharge orders are marked correctly
    console.log('\n\n📋 Checking Order List for Proxy Recharge Orders...');
    const ordersResponse = await axios.get(`${API_BASE}/order/admin/list`, {
      params: {
        page: 1,
        pageSize: 10
      },
      headers: {
        'Authorization': `Bearer ${adminToken}`
      }
    });
    
    if (ordersResponse.data.code === 0 && ordersResponse.data.data) {
      const orders = ordersResponse.data.data.list || [];
      const proxyOrders = orders.filter(o => o.isProxyRecharge || o.deliveryRequiresReceipt);
      
      console.log('Total orders:', orders.length);
      console.log('Proxy recharge orders:', proxyOrders.length);
      
      proxyOrders.forEach((order, index) => {
        console.log(`\n--- Proxy Order ${index + 1} ---`);
        console.log('Order No:', order.orderNo);
        console.log('Product Name:', order.productName);
        console.log('Is Proxy Recharge:', order.isProxyRecharge);
        console.log('Delivery Requires Receipt:', order.deliveryRequiresReceipt);
      });
    }
    
  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
    }
  }
}

testAdminReceiptView();