/**
 * 测试用户ID 12的通知获取
 * Run: node test-user-id-12-notifications.js
 */

import axios from 'axios';
import jwt from 'jsonwebtoken';

const API_BASE = 'http://localhost:3002/api';
const JWT_SECRET = process.env.JWT_SECRET || 'jiujiu-admin-secret-key-2024';

async function testUserNotifications() {
  try {
    console.log('🔔 测试用户ID 12的通知功能\n');
    
    // 1. 为用户ID 12创建一个临时token（绕过登录）
    const userId = 12;
    const token = jwt.sign(
      { 
        id: userId,
        userId: userId,
        email: 'user12@example.com',
        role: 'user'
      },
      JWT_SECRET,
      { expiresIn: '1h' }
    );
    
    console.log('✅ 为用户ID 12生成了临时令牌\n');
    
    // 2. 获取未读通知数量
    console.log('步骤1: 获取未读通知数量');
    try {
      const unreadResponse = await axios.get(
        `${API_BASE}/notification/unread-count`,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      console.log('📊 未读通知数量:', unreadResponse.data.data.count);
    } catch (error) {
      console.log('❌ 获取未读数量失败:', error.response?.data || error.message);
    }
    
    // 3. 获取通知列表
    console.log('\n步骤2: 获取通知列表');
    try {
      const notificationsResponse = await axios.get(
        `${API_BASE}/notification/list`,
        {
          params: {
            page: 1,
            pageSize: 10
          },
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      if (notificationsResponse.data.data && notificationsResponse.data.data.list) {
        const notifications = notificationsResponse.data.data.list;
        console.log(`📬 共有 ${notifications.length} 条通知\n`);
        
        notifications.forEach((notification, index) => {
          console.log(`--- 通知 ${index + 1} ---`);
          console.log('  ID:', notification.id);
          console.log('  标题:', notification.title);
          console.log('  内容:', notification.content);
          console.log('  类型:', notification.type);
          console.log('  已读:', notification.isRead ? '是' : '否');
          console.log('  关联订单:', notification.relatedId);
          console.log('  时间:', new Date(notification.createdAt).toLocaleString('zh-CN'));
          console.log('');
        });
        
        console.log('✅ 通知获取成功！');
        console.log('\n用户应该能在界面上看到这些通知。');
        
      } else {
        console.log('📭 暂无通知');
      }
    } catch (error) {
      console.log('❌ 获取通知列表失败:', error.response?.data || error.message);
    }
    
    // 4. 检查前端组件
    console.log('\n📌 前端检查事项:');
    console.log('1. NotificationBell组件是否已添加到页面');
    console.log('2. 通知API的token是否正确传递');
    console.log('3. 用户登录后的userId是否正确');
    console.log('4. 检查浏览器控制台是否有错误');
    
  } catch (error) {
    console.error('\n❌ 错误:', error.message);
  }
}

testUserNotifications();