import pool from './src/db/database.js';

async function checkOrders() {
  try {
    // 获取你要删除的商品ID
    console.log('请输入要删除的商品ID:');
    const productId = process.argv[2] || '14'; // 默认查询商品ID 14
    
    console.log(`\n查询商品ID ${productId} 的订单状态...`);
    
    // 查询该商品的所有订单
    const [orders] = await pool.execute(
      `SELECT 
        id,
        order_no,
        product_id,
        product_name,
        order_status,
        payment_status,
        delivery_status,
        created_at
      FROM \`order\` 
      WHERE product_id = ?
      ORDER BY id DESC`,
      [productId]
    );
    
    console.log(`\n找到 ${orders.length} 个订单:`);
    
    if (orders.length > 0) {
      console.log('\n订单详情:');
      orders.forEach(order => {
        const statusText = {
          0: '待处理',
          1: '处理中',
          2: '已完成',
          3: '已取消',
          4: '已退款'
        };
        
        console.log(`\n订单号: ${order.order_no}`);
        console.log(`  商品: ${order.product_name}`);
        console.log(`  订单状态: ${order.order_status} (${statusText[order.order_status] || '未知'})`);
        console.log(`  支付状态: ${order.payment_status}`);
        console.log(`  发货状态: ${order.delivery_status}`);
        console.log(`  创建时间: ${order.created_at}`);
      });
      
      // 统计未完成的订单
      const unfinishedOrders = orders.filter(o => o.order_status === 0 || o.order_status === 1);
      console.log(`\n未完成订单数量: ${unfinishedOrders.length}`);
      
      if (unfinishedOrders.length > 0) {
        console.log('未完成订单列表:');
        unfinishedOrders.forEach(order => {
          console.log(`  - ${order.order_no} (状态: ${order.order_status})`);
        });
      }
    }
    
    // 查询所有商品及其订单数
    const [productStats] = await pool.execute(
      `SELECT 
        p.id,
        p.title,
        COUNT(o.id) as total_orders,
        SUM(CASE WHEN o.order_status IN (0, 1) THEN 1 ELSE 0 END) as unfinished_orders
      FROM pr_goods p
      LEFT JOIN \`order\` o ON p.id = o.product_id
      GROUP BY p.id
      HAVING total_orders > 0
      ORDER BY unfinished_orders DESC, p.id DESC
      LIMIT 10`
    );
    
    console.log('\n\n商品订单统计（前10个有订单的商品）:');
    console.log('ID\t商品名称\t\t\t总订单数\t未完成订单数');
    console.log('-'.repeat(70));
    productStats.forEach(stat => {
      const title = stat.title.length > 20 ? stat.title.substring(0, 20) + '...' : stat.title;
      console.log(`${stat.id}\t${title.padEnd(25)}\t${stat.total_orders}\t\t${stat.unfinished_orders}`);
    });
    
    process.exit(0);
  } catch (error) {
    console.error('查询失败:', error);
    process.exit(1);
  }
}

checkOrders();