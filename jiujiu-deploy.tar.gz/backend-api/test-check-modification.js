/**
 * 检查修改申请状态
 * Run: node test-check-modification.js
 */

import axios from 'axios';

const API_BASE = 'http://localhost:3002/api';

async function checkModificationStatus() {
  try {
    console.log('🔍 检查回执单修改申请状态\n');
    
    // 1. 管理员登录
    const adminResponse = await axios.post(`${API_BASE}/auth/login`, {
      email: 'admin@example.com',
      password: 'admin123456'
    });
    
    const adminToken = adminResponse.data.token;
    console.log('✅ 管理员登录成功\n');
    
    // 2. 获取回执单详情
    const orderNo = 'ORD1757839240567870';
    const response = await axios.get(
      `${API_BASE}/order/admin/receipts/${orderNo}`,
      {
        headers: {
          'Authorization': `Bearer ${adminToken}`
        }
      }
    );
    
    console.log('📋 订单回执单信息:');
    console.log('=====================================\n');
    
    if (response.data.data && response.data.data.receipts) {
      const receipts = response.data.data.receipts;
      
      receipts.forEach((receipt, index) => {
        console.log(`回执单 ${index + 1}:`);
        console.log('  ID:', receipt.id);
        console.log('  回执数据:', JSON.stringify(receipt.receiptData, null, 2));
        console.log('  Notes原始值:', receipt.notes);
        
        if (receipt.notes) {
          try {
            const notes = JSON.parse(receipt.notes);
            console.log('\n  📝 解析后的Notes:');
            console.log('  ', JSON.stringify(notes, null, 2));
            
            if (notes.modificationRequest) {
              console.log('\n  ⚠️  修改申请信息:');
              console.log('    状态:', notes.modificationRequest.status);
              console.log('    原因:', notes.modificationRequest.reason);
              console.log('    提交时间:', notes.modificationRequest.requestedAt || notes.modificationRequest.submittedAt);
              console.log('    新数据:', JSON.stringify(notes.modificationRequest.newData, null, 4));
              
              // 检查状态
              if (notes.modificationRequest.status === 'pending') {
                console.log('\n  ✅ 状态为 pending，应该显示审核按钮');
              } else {
                console.log('\n  ❌ 状态不是 pending，当前状态:', notes.modificationRequest.status);
              }
            } else {
              console.log('\n  ℹ️  没有修改申请');
            }
          } catch (e) {
            console.log('\n  ❌ Notes解析失败:', e.message);
          }
        } else {
          console.log('\n  ℹ️  Notes字段为空');
        }
        
        console.log('\n-------------------------------------\n');
      });
      
      // 检查前端条件
      console.log('📌 前端显示审核按钮的条件:');
      console.log('1. row.notes 存在 ✓');
      console.log('2. parseNotes(row.notes).modificationRequest 存在 ✓');
      console.log('3. parseNotes(row.notes).modificationRequest.status === "pending" ✓');
      console.log('\n如果以上条件都满足，应该显示"通过"和"拒绝"按钮');
      
    } else {
      console.log('没有找到回执单');
    }
    
  } catch (error) {
    console.error('❌ 错误:', error.response?.data || error.message);
  }
}

checkModificationStatus();