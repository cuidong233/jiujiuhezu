import dotenv from 'dotenv';
import { readFileSync } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config();

export const wechatConfig = {
  appId: process.env.WX_APP_ID || 'wx36273952367fe98d',
  appSecret: process.env.WX_APP_SECRET || '293763493d6da344afea2bfde4c24544',
  
  pay: {
    mchId: process.env.WX_MCH_ID || '1716074381',
    mchKey: process.env.WX_MCH_KEY || 'lWm9tNYwCIDsnzhedfqz1QVvK4pmAoBb',
    apiV3Key: process.env.WX_API_V3_KEY || 'lWm9tNYwCIDsnzhedfqz1QVvK4pmAoBb',
    certSerialNo: process.env.WX_CERT_SERIAL_NO || '213CDA850819FB39885BABDC2E7DF090562177E6',
    
    privateKey: process.env.WX_PRIVATE_KEY || (() => {
      try {
        return readFileSync(join(__dirname, '../certs/apiclient_key.pem'), 'utf8');
      } catch (error) {
        console.warn('微信支付私钥文件未找到，请配置私钥路径');
        return '';
      }
    })(),
    
    certificate: process.env.WX_CERTIFICATE || (() => {
      try {
        return readFileSync(join(__dirname, '../certs/apiclient_cert.pem'), 'utf8');
      } catch (error) {
        console.warn('微信支付证书文件未找到，请配置证书路径');
        return '';
      }
    })(),
    
    notifyUrl: process.env.WX_PAY_NOTIFY_URL || 'https://en.api.jjhezu.com/api/wechat/pay/callback',
    
    useSandbox: process.env.WX_USE_SANDBOX === 'true' || false
  }
};

export const validateWechatConfig = () => {
  const required = [
    'appId',
    'appSecret',
    'pay.mchId',
    'pay.mchKey',
    'pay.apiV3Key',
    'pay.certSerialNo'
  ];
  
  const missing = [];
  
  for (const field of required) {
    const keys = field.split('.');
    let value = wechatConfig;
    for (const key of keys) {
      value = value[key];
    }
    if (!value) {
      missing.push(field);
    }
  }
  
  if (missing.length > 0) {
    console.error('微信支付配置缺失：', missing.join(', '));
    return false;
  }
  
  return true;
};