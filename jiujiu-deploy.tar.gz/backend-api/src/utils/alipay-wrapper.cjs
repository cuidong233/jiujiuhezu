const AlipaySdk = require('alipay-sdk').default;
module.exports = AlipaySdk;