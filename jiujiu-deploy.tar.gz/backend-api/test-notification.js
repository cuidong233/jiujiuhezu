import axios from 'axios';

const API_BASE = 'http://localhost:3002/api';

// 用户的 token（需要是有效的）
const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyLCJlbWFpbCI6ImN1aWRvbmcxMTFAZ21haWwuY29tIiwicm9sZSI6InVzZXIiLCJpYXQiOjE3NTc4NjM4MzcsImV4cCI6MTc1ODQ2ODYzN30.Ir-nymLsASJu4lXsrNVrJIl76VNRJR2yJLaNGkCJQZc';

async function testNotificationAPI() {
  try {
    console.log('测试通知API...\n');
    
    // 测试获取通知列表
    const listResponse = await axios.get(`${API_BASE}/notification/list`, {
      params: {
        page: 1,
        pageSize: 10
      },
      headers: {
        'token': token
      }
    });
    
    console.log('通知列表响应:');
    console.log('状态码:', listResponse.status);
    console.log('响应数据:', JSON.stringify(listResponse.data, null, 2));
    
    // 测试获取未读数量
    const unreadResponse = await axios.get(`${API_BASE}/notification/unread-count`, {
      headers: {
        'token': token
      }
    });
    
    console.log('\n未读数量响应:');
    console.log('状态码:', unreadResponse.status);
    console.log('响应数据:', JSON.stringify(unreadResponse.data, null, 2));
    
  } catch (error) {
    console.error('API调用失败:', error.response ? error.response.data : error.message);
  }
}

testNotificationAPI();