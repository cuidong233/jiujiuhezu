/**
 * 查找用户ID 12的登录信息
 * Run: node test-find-user-12.js
 */

import { User } from './src/models/index.js';
import sequelize from './src/db/sequelize.js';

async function findUser12() {
  try {
    console.log('🔍 查找用户ID 12的信息\n');
    
    const user = await User.findByPk(12);
    
    if (user) {
      console.log('✅ 找到用户:');
      console.log('  ID:', user.id);
      console.log('  邮箱:', user.email);
      console.log('  昵称:', user.nickname);
      console.log('  角色:', user.role);
      console.log('  创建时间:', user.createdAt);
      console.log('');
      console.log('📌 登录信息:');
      console.log('  邮箱:', user.email);
      console.log('  密码: (需要知道原始密码才能登录)');
      console.log('');
      console.log('💡 提示:');
      console.log('1. 用户需要使用邮箱 "' + user.email + '" 登录');
      console.log('2. 登录后才能在个人中心看到通知');
      console.log('3. 或者可以在订单页面查看该订单的回执状态');
    } else {
      console.log('❌ 未找到用户ID 12');
    }
    
    // 查找所有用户看看有哪些测试账号
    console.log('\n📋 所有用户列表:');
    const allUsers = await User.findAll({
      attributes: ['id', 'email', 'nickname', 'role'],
      limit: 10
    });
    
    allUsers.forEach(u => {
      console.log(`  ID ${u.id}: ${u.email} (${u.role})`);
    });
    
    await sequelize.close();
    
  } catch (error) {
    console.error('❌ 错误:', error);
    await sequelize.close();
  }
}

findUser12();