import pool from './src/db/database.js';

async function testQuery() {
  try {
    console.log('Testing recent-transactions query...');
    
    const limit = 10;
    const [transactions] = await pool.execute(
      `SELECT 
        o.order_no as orderNo,
        u.username as user,
        o.total_amount as amount,
        'consume' as type,
        o.payment_method as method,
        CASE 
          WHEN o.payment_status = 1 THEN 'completed'
          WHEN o.payment_status = 2 THEN 'failed'
          ELSE 'pending'
        END as status,
        o.created_at as time
       FROM \`order\` o
       LEFT JOIN users u ON o.user_id = u.id
       ORDER BY o.created_at DESC
       LIMIT ?`,
      [parseInt(limit)]
    );
    
    console.log('Query successful!');
    console.log('Found', transactions.length, 'transactions');
    if (transactions.length > 0) {
      console.log('First transaction:', transactions[0]);
    }
  } catch (error) {
    console.error('Query failed:', error.message);
    console.error('Full error:', error);
  } finally {
    process.exit();
  }
}

testQuery();