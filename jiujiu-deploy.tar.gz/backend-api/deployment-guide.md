# 海外部署指南

## 推荐的云服务商（海外用户）

### 1. **Vercel / Netlify**（前端）
- 免费套餐足够
- 全球CDN加速
- 自动HTTPS

### 2. **后端服务器选择**

#### AWS (Amazon Web Services)
- EC2免费套餐：1年免费
- 地区选择：美国(us-east-1)、欧洲(eu-west-1)、新加坡(ap-southeast-1)
- Gmail连接：✅ 完美支持

#### Google Cloud Platform
- 免费试用：$300额度
- 地区选择：任意
- Gmail连接：✅ 原生支持（同一家公司）

#### DigitalOcean
- 价格：$5/月起
- 地区选择：纽约、旧金山、伦敦、新加坡
- Gmail连接：✅ 完美支持

#### Heroku
- 免费套餐（已取消）
- 价格：$7/月起
- Gmail连接：✅ 支持

## 部署后的邮件配置

### Gmail（推荐用于海外）
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=yourapp@gmail.com
SMTP_PASS=应用专用密码
```
**优势**：
- 海外用户信任度高
- 垃圾邮件率低
- 免费额度：500封/天

### SendGrid（专业选择）
```env
SENDGRID_API_KEY=your-api-key
```
**优势**：
- 免费额度：100封/天
- 专业邮件追踪
- 高送达率

### Amazon SES（大规模）
```env
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret
AWS_REGION=us-east-1
```
**优势**：
- 极低成本：$0.10/1000封
- 高可靠性
- 适合大规模发送

## 本地开发建议

### 1. 开发时使用模拟模式
当前配置已经完美支持开发：
- 验证码显示在控制台
- 功能完全正常
- 不影响开发测试

### 2. 使用环境变量区分
```javascript
if (process.env.NODE_ENV === 'development') {
  // 开发环境：显示验证码
  console.log('验证码：', code);
} else {
  // 生产环境：发送邮件
  await transporter.sendMail(mailOptions);
}
```

## 部署检查清单

- [ ] 选择海外服务器（AWS/GCP/DigitalOcean）
- [ ] 配置域名（可选）
- [ ] 设置环境变量
- [ ] 配置SSL证书（自动）
- [ ] 测试Gmail发送
- [ ] 设置备用邮件服务（可选）

## 成本预估

### 小规模（<1000用户）
- 前端：$0（Vercel免费）
- 后端：$5-10/月（DigitalOcean）
- 邮件：$0（Gmail免费额度）
- **总计：$5-10/月**

### 中等规模（1000-10000用户）
- 前端：$0-20/月
- 后端：$20-50/月
- 邮件：$0-35/月（SendGrid）
- **总计：$20-85/月**

### 大规模（>10000用户）
- 前端：$20+/月
- 后端：$100+/月
- 邮件：$10+/月（Amazon SES）
- **总计：$130+/月**