/**
 * 完整测试回执单修改申请流程
 * Run: node test-full-receipt-flow.js
 */

import axios from 'axios';

const API_BASE = 'http://localhost:3002/api';

async function testFullReceiptFlow() {
  try {
    console.log('🔍 测试完整的回执单修改申请流程...\n');
    
    // 1. 用户登录
    console.log('步骤1: 用户登录');
    const userLoginResponse = await axios.post(`${API_BASE}/auth/login`, {
      email: 'test@example.com',
      password: 'test123456'
    });
    
    const userToken = userLoginResponse.data.token;
    console.log('✅ 用户登录成功\n');
    
    // 2. 获取订单的回执单信息
    const orderNo = 'ORD1757839240567870';
    console.log(`步骤2: 获取订单 ${orderNo} 的回执单信息`);
    
    const userReceiptResponse = await axios.get(
      `${API_BASE}/order/receipts/${orderNo}`,
      {
        headers: {
          'Authorization': `Bearer ${userToken}`
        }
      }
    );
    
    console.log('回执单数据:', JSON.stringify(userReceiptResponse.data.data.receipts[0], null, 2));
    console.log('✅ 成功获取回执单信息\n');
    
    // 3. 提交修改申请
    console.log('步骤3: 提交修改申请');
    const modificationData = {
      receiptData: {
        gameAccount: 'newGameAccount2024',
        gamePassword: 'newSecurePassword',
        contact: 'newemail@example.com',
        remark: '请尽快处理，之前账号填错了'
      },
      reason: '账号信息输入错误，需要更正为正确的游戏账号'
    };
    
    try {
      const modifyResponse = await axios.post(
        `${API_BASE}/order/receipts/${orderNo}/modify`,
        modificationData,
        {
          headers: {
            'Authorization': `Bearer ${userToken}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      console.log('修改申请响应:', modifyResponse.data);
      console.log('✅ 修改申请提交成功\n');
    } catch (error) {
      console.log('⚠️  修改申请可能已存在或遇到错误:', error.response?.data?.message || error.message);
    }
    
    // 4. 管理员登录
    console.log('步骤4: 管理员登录');
    const adminLoginResponse = await axios.post(`${API_BASE}/auth/login`, {
      email: 'admin@example.com',
      password: 'admin123456'
    });
    
    const adminToken = adminLoginResponse.data.token;
    console.log('✅ 管理员登录成功\n');
    
    // 5. 管理员查看回执单（包含修改申请）
    console.log('步骤5: 管理员查看回执单信息');
    const adminReceiptResponse = await axios.get(
      `${API_BASE}/order/admin/receipts/${orderNo}`,
      {
        headers: {
          'Authorization': `Bearer ${adminToken}`
        }
      }
    );
    
    if (adminReceiptResponse.data.data && adminReceiptResponse.data.data.receipts) {
      const receipts = adminReceiptResponse.data.data.receipts;
      console.log(`\n📋 订单 ${orderNo} 的回执单信息:`);
      
      receipts.forEach((receipt, index) => {
        console.log(`\n--- 回执单 ${index + 1} ---`);
        console.log('ID:', receipt.id);
        console.log('CDK码:', receipt.cdkCode);
        console.log('当前回执数据:', JSON.stringify(receipt.receiptData, null, 2));
        console.log('Notes字段原始值:', receipt.notes);
        
        // 解析并显示修改申请
        if (receipt.notes) {
          try {
            const notes = JSON.parse(receipt.notes);
            if (notes.modificationRequest) {
              console.log('\n⚠️  发现修改申请:');
              console.log('  状态:', notes.modificationRequest.status);
              console.log('  原因:', notes.modificationRequest.reason);
              console.log('  申请时间:', notes.modificationRequest.requestedAt);
              console.log('  新数据:', JSON.stringify(notes.modificationRequest.newData, null, 2));
            } else {
              console.log('\n✅ 暂无修改申请');
            }
          } catch (e) {
            console.log('\n⚠️  Notes字段不是有效的JSON:', e.message);
          }
        } else {
          console.log('\n✅ 暂无修改申请（notes为空）');
        }
      });
    }
    
    console.log('\n\n✅ 测试完成！管理员现在应该能看到用户的修改申请了。');
    
  } catch (error) {
    console.error('\n❌ 测试失败:', error.response?.data || error.message);
    if (error.response) {
      console.error('错误详情:', {
        status: error.response.status,
        data: error.response.data
      });
    }
  }
}

testFullReceiptFlow();