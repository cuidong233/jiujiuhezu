#!/bin/bash

echo "========================================="
echo "启动内网穿透服务..."
echo "========================================="

# 安装localtunnel（如果未安装）
if ! command -v lt &> /dev/null; then
    echo "正在安装localtunnel..."
    npm install -g localtunnel
fi

# 启动穿透服务
echo "正在启动内网穿透，端口: 3002"
echo ""
echo "⚠️  重要提示："
echo "1. 获得URL后，需要更新 .env 文件中的 WX_PAY_NOTIFY_URL"
echo "2. 格式: https://[subdomain].loca.lt/api/wechat/pay/callback"
echo "3. 首次访问需要在浏览器中打开URL并输入你的IP地址验证"
echo ""
echo "========================================="

# 启动localtunnel
npx localtunnel --port 3002 --subdomain jiujiu-pay-$(date +%s)

# 如果上面的命令失败，使用随机subdomain
if [ $? -ne 0 ]; then
    echo "使用随机subdomain重试..."
    npx localtunnel --port 3002
fi