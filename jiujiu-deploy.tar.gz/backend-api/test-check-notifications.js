/**
 * 检查通知记录
 * Run: node test-check-notifications.js
 */

import { Notification, Order } from './src/models/index.js';
import sequelize from './src/db/sequelize.js';

async function checkNotifications() {
  try {
    console.log('🔍 检查通知记录\n');
    
    // 1. 查找订单获取用户ID
    const orderNo = 'ORD1757839240567870';
    const order = await Order.findOne({
      where: { orderNo }
    });
    
    if (!order) {
      console.log('❌ 未找到订单');
      return;
    }
    
    console.log('📦 订单信息:');
    console.log('  订单号:', order.orderNo);
    console.log('  用户ID:', order.userId);
    console.log('');
    
    // 2. 查找该用户的所有通知
    const notifications = await Notification.findAll({
      where: { userId: order.userId },
      order: [['createdAt', 'DESC']]
    });
    
    console.log(`📬 找到 ${notifications.length} 条通知:\n`);
    
    notifications.forEach((notification, index) => {
      console.log(`通知 ${index + 1}:`);
      console.log('  ID:', notification.id);
      console.log('  标题:', notification.title);
      console.log('  内容:', notification.content);
      console.log('  类型:', notification.type);
      console.log('  关联订单:', notification.relatedId);
      console.log('  已读:', notification.isRead ? '是' : '否');
      console.log('  创建时间:', notification.createdAt);
      console.log('  元数据:', JSON.stringify(notification.metadata, null, 2));
      console.log('----------------------------\n');
    });
    
    // 3. 查找最近的回执相关通知
    const receiptNotifications = notifications.filter(n => 
      n.type === 'receipt_approved' || n.type === 'receipt_rejected'
    );
    
    if (receiptNotifications.length > 0) {
      console.log('✅ 找到回执相关通知:');
      receiptNotifications.forEach(n => {
        console.log(`  - ${n.type}: ${n.title}`);
      });
    } else {
      console.log('❌ 没有找到回执相关通知');
      console.log('\n可能的原因:');
      console.log('1. 通知创建失败');
      console.log('2. 用户ID不匹配');
      console.log('3. 审核操作没有触发通知创建');
    }
    
    await sequelize.close();
    
  } catch (error) {
    console.error('❌ 错误:', error);
    await sequelize.close();
  }
}

checkNotifications();