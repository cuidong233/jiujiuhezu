/**
 * Test modification request submission
 * Run: node test-modification-request.js
 */

import axios from 'axios';

const API_BASE = 'http://localhost:3002/api';

async function testModificationRequest() {
  try {
    console.log('Testing modification request submission...');
    
    // 1. User login
    const loginResponse = await axios.post(`${API_BASE}/auth/login`, {
      email: 'test@example.com',
      password: 'test123456'
    });
    
    const token = loginResponse.data.token;
    console.log('✅ User login successful');
    
    // 2. Submit modification request
    const orderNo = 'ORD1757839240567870';
    const modificationData = {
      receiptData: {
        gameAccount: 'newAccount456',
        gamePassword: 'newPassword789',
        contact: 'newemail@example.com',
        remark: 'Updated information'
      },
      reason: '账号输入错误，需要更正'
    };
    
    console.log('Submitting modification request for order:', orderNo);
    console.log('Modification data:', modificationData);
    
    const modResponse = await axios.post(
      `${API_BASE}/order/receipts/${orderNo}/modify`,
      modificationData,
      {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    console.log('✅ Modification request response:', modResponse.data);
    
    // 3. Now check as admin to see the modification request
    console.log('\n--- Checking as Admin ---');
    
    const adminLoginResponse = await axios.post(`${API_BASE}/auth/login`, {
      email: 'admin@example.com',
      password: 'admin123456'
    });
    
    const adminToken = adminLoginResponse.data.token;
    console.log('✅ Admin login successful');
    
    const receiptResponse = await axios.get(
      `${API_BASE}/order/admin/receipts/${orderNo}`,
      {
        headers: {
          'Authorization': `Bearer ${adminToken}`
        }
      }
    );
    
    console.log('\n📋 Admin View - Receipt Information:');
    if (receiptResponse.data.data && receiptResponse.data.data.receipts) {
      const receipts = receiptResponse.data.data.receipts;
      receipts.forEach((receipt, index) => {
        console.log(`\n--- Receipt ${index + 1} ---`);
        console.log('Receipt Data:', receipt.receiptData);
        console.log('Notes:', receipt.notes);
        
        // Check for modification request in notes
        if (receipt.notes) {
          try {
            const notes = JSON.parse(receipt.notes);
            if (notes.modificationRequest) {
              console.log('\n⚠️  MODIFICATION REQUEST DETECTED:');
              console.log('Status:', notes.modificationRequest.status);
              console.log('Reason:', notes.modificationRequest.reason);
              console.log('New Data:', notes.modificationRequest.newData);
              console.log('Submitted At:', notes.modificationRequest.submittedAt);
            }
          } catch (e) {
            console.log('Notes is not JSON:', receipt.notes);
          }
        }
      });
    }
    
  } catch (error) {
    console.error('❌ Error:', error.response?.data || error.message);
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
    }
  }
}

testModificationRequest();