/**
 * 测试提交回执单
 */
import axios from 'axios';

async function testSubmitReceipt() {
  const API_BASE = 'http://localhost:3002/api';
  
  try {
    // 1. 登录获取token
    console.log('1. 登录获取token...');
    const loginRes = await axios.post(`${API_BASE}/auth/login`, {
      email: 'cuidong111@gmail.com',
      password: 'Aa123456'  // 尝试常见密码
    });
    
    const token = loginRes.data.data?.token;
    if (!token) {
      console.error('登录失败，无法获取token');
      console.log('登录响应:', loginRes.data);
      return;
    }
    
    console.log('登录成功，token:', token.substring(0, 20) + '...');
    
    // 2. 提交回执单
    console.log('\n2. 提交回执单...');
    const orderNo = 'ORD1757895227402922';
    
    const submitRes = await axios.post(
      `${API_BASE}/order/receipts/${orderNo}/submit`,
      {
        gameAccount: 'testAccount123',
        gamePassword: 'password123',
        contact: 'cuidong111@gmail.com',
        remark: '测试提交回执单'
      },
      {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    console.log('提交回执单成功:', submitRes.data);
    
  } catch (error) {
    if (error.response) {
      console.error('请求失败:', error.response.data);
      console.error('状态码:', error.response.status);
    } else {
      console.error('请求错误:', error.message);
    }
  }
}

// 运行测试
testSubmitReceipt().catch(console.error);