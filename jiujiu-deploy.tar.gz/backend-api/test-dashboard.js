import express from 'express';
import pool from './src/db/database.js';

const app = express();

app.get('/test', async (req, res) => {
  try {
    const limit = 10;
    
    console.log('Executing query...');
    const [transactions] = await pool.execute(
      `SELECT 
        o.order_no as orderNo,
        u.username,
        o.total_amount as amount,
        'consume' as type,
        o.payment_method as method,
        CASE 
          WHEN o.payment_status = 1 THEN 'completed'
          WHEN o.payment_status = 2 THEN 'failed'
          ELSE 'pending'
        END as status,
        o.created_at as time
       FROM \`order\` o
       LEFT JOIN users u ON o.user_id = u.id
       ORDER BY o.created_at DESC
       LIMIT ?`,
      [parseInt(limit)]
    );
    
    console.log('Query successful, found', transactions.length, 'transactions');
    
    // Map username to user field for frontend compatibility
    const formattedTransactions = transactions.map(t => ({
      ...t,
      user: t.username,
      username: undefined
    }));
    
    res.json({
      code: 0,
      msg: 'success',
      data: formattedTransactions
    });
  } catch (error) {
    console.error('获取最新交易失败:', error);
    console.error('Error message:', error.message);
    console.error('SQL:', error.sql);
    res.status(500).json({
      code: 500,
      msg: '获取最新交易失败',
      error: error.message
    });
  }
});

app.listen(3003, () => {
  console.log('Test server running on port 3003');
});