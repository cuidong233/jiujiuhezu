#!/bin/bash

echo "========================================="
echo "启动cpolar内网穿透（国内服务）"
echo "========================================="

# 检查是否安装了cpolar
if ! command -v cpolar &> /dev/null; then
    echo "请先安装cpolar："
    echo ""
    echo "1. 访问 https://www.cpolar.com/download"
    echo "2. 下载Mac版本"
    echo "3. 解压后运行："
    echo "   unzip cpolar-stable-darwin-amd64.zip"
    echo "   sudo mv cpolar /usr/local/bin/"
    echo "   chmod +x /usr/local/bin/cpolar"
    echo ""
    echo "或者使用brew安装："
    echo "   brew tap probezy/cpolar"
    echo "   brew install cpolar"
    exit 1
fi

echo ""
echo "启动cpolar隧道（端口3002）..."
echo ""
echo "⚠️  获得URL后，请："
echo "1. 使用 node update-callback-url.js 更新配置"
echo "2. 重启后端服务"
echo ""
echo "========================================="

# 启动cpolar（免费版不需要认证）
cpolar http 3002