#!/bin/bash

echo "========================================="
echo "Localtunnel 验证助手"
echo "========================================="
echo ""

# 获取公网IP
echo "正在获取你的公网IP地址..."
PUBLIC_IP=$(curl -s ifconfig.me)

if [ -z "$PUBLIC_IP" ]; then
    echo "❌ 无法获取IP地址，请手动访问 https://whatismyipaddress.com"
else
    echo "✅ 你的公网IP地址是: $PUBLIC_IP"
    echo ""
    echo "========================================="
    echo "请按以下步骤操作："
    echo ""
    echo "1. 在浏览器中打开你的localtunnel URL"
    echo "2. 当页面要求输入IP地址时"
    echo "3. 输入: $PUBLIC_IP"
    echo "4. 点击提交"
    echo ""
    echo "验证成功后，页面会显示 'Tunnel is active'"
    echo "========================================="
    
    # 复制到剪贴板（Mac）
    echo $PUBLIC_IP | pbcopy
    echo ""
    echo "💡 提示：IP地址已复制到剪贴板，可以直接粘贴"
fi