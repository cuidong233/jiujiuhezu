/**
 * 测试用户通知功能
 * Run: node test-user-notifications.js
 */

import axios from 'axios';

const API_BASE = 'http://localhost:3002/api';

async function testUserNotifications() {
  try {
    console.log('🔔 测试用户通知功能\n');
    console.log('=====================================\n');
    
    // 1. 用户登录
    console.log('步骤1: 用户登录');
    const userLoginResponse = await axios.post(`${API_BASE}/auth/login`, {
      email: 'admin@example.com',
      password: 'admin123456'
    });
    
    const userToken = userLoginResponse.data.token;
    console.log('✅ 用户登录成功\n');
    
    // 2. 获取未读通知数量
    console.log('步骤2: 获取未读通知数量');
    const unreadResponse = await axios.get(
      `${API_BASE}/notification/unread-count`,
      {
        headers: {
          'Authorization': `Bearer ${userToken}`
        }
      }
    );
    
    console.log('📊 未读通知数量:', unreadResponse.data.data.count);
    
    // 3. 获取通知列表
    console.log('\n步骤3: 获取通知列表');
    const notificationsResponse = await axios.get(
      `${API_BASE}/notification/list`,
      {
        params: {
          page: 1,
          pageSize: 10
        },
        headers: {
          'Authorization': `Bearer ${userToken}`
        }
      }
    );
    
    if (notificationsResponse.data.data && notificationsResponse.data.data.list) {
      const notifications = notificationsResponse.data.data.list;
      console.log(`📬 共有 ${notifications.length} 条通知\n`);
      
      notifications.forEach((notification, index) => {
        console.log(`--- 通知 ${index + 1} ---`);
        console.log('  标题:', notification.title);
        console.log('  内容:', notification.content);
        console.log('  类型:', notification.type);
        console.log('  已读:', notification.isRead ? '是' : '否');
        console.log('  时间:', new Date(notification.createdAt).toLocaleString('zh-CN'));
        
        if (notification.relatedType === 'order') {
          console.log('  关联订单:', notification.relatedId);
        }
        console.log('');
      });
      
      // 4. 标记第一条未读通知为已读
      const unreadNotification = notifications.find(n => !n.isRead);
      if (unreadNotification) {
        console.log('步骤4: 标记通知为已读');
        console.log('标记通知ID:', unreadNotification.id);
        
        const markReadResponse = await axios.put(
          `${API_BASE}/notification/${unreadNotification.id}/read`,
          {},
          {
            headers: {
              'Authorization': `Bearer ${userToken}`
            }
          }
        );
        
        if (markReadResponse.data.code === 200) {
          console.log('✅ 通知已标记为已读');
        }
      }
      
    } else {
      console.log('📭 暂无通知');
    }
    
    console.log('\n=====================================');
    console.log('✅ 通知系统测试完成！');
    console.log('\n用户界面功能:');
    console.log('1. ✅ 用户可以查看通知列表');
    console.log('2. ✅ 用户可以看到未读通知数量');
    console.log('3. ✅ 用户可以标记通知为已读');
    console.log('4. ✅ 用户可以查看订单相关通知');
    
  } catch (error) {
    console.error('\n❌ 测试失败:', error.response?.data || error.message);
    if (error.response) {
      console.error('错误详情:', {
        status: error.response.status,
        data: error.response.data
      });
    }
  }
}

testUserNotifications();