#!/bin/bash

echo "========================================="
echo "启动localtunnel（简单版）"
echo "========================================="
echo ""

# 直接启动，不指定subdomain
echo "启动隧道..."
npx localtunnel --port 3002 --print-requests

echo ""
echo "如果上面的命令失败，尝试："
echo "npm install -g localtunnel"
echo "lt --port 3002"