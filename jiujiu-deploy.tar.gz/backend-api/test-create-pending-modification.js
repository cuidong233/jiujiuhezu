/**
 * 直接在数据库中创建待审核的修改申请
 * Run: node test-create-pending-modification.js
 */

import { CDKReceipt } from './src/models/index.js';
import sequelize from './src/db/sequelize.js';

async function createPendingModification() {
  try {
    console.log('📝 直接创建待审核的修改申请\n');
    
    // 查找回执单
    const receipt = await CDKReceipt.findByPk(5);
    
    if (!receipt) {
      console.log('❌ 未找到ID为5的回执单');
      return;
    }
    
    console.log('找到回执单:');
    console.log('  当前数据:', receipt.receiptData);
    console.log('  当前Notes:', receipt.notes);
    
    // 创建新的待审核修改申请
    const newModificationRequest = {
      reason: '账号密码填写错误，需要更新为正确的信息',
      newData: {
        account: 'TestAccount2024',
        password: 'TestPassword2024!',
        server: '欧洲服务器',
        remark: '请尽快处理，这是正确的账号信息'
      },
      requestedAt: new Date().toISOString(),
      status: 'pending'  // 关键：设置为pending状态
    };
    
    // 更新notes字段
    const notes = { modificationRequest: newModificationRequest };
    receipt.notes = JSON.stringify(notes);
    
    await receipt.save();
    
    console.log('\n✅ 修改申请已创建！');
    console.log('新的Notes内容:', JSON.stringify(notes, null, 2));
    console.log('\n🎯 现在状态是 pending，管理员应该能看到审核按钮了！');
    console.log('请在管理后台查看订单 ORD1757839240567870 的详情');
    
    await sequelize.close();
    
  } catch (error) {
    console.error('❌ 错误:', error);
    await sequelize.close();
  }
}

createPendingModification();