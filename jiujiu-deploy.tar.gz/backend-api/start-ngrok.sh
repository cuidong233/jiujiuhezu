#!/bin/bash

echo "========================================="
echo "启动ngrok内网穿透"
echo "========================================="

# 检查是否安装了ngrok
if ! command -v ngrok &> /dev/null; then
    echo "正在安装ngrok..."
    brew install ngrok
fi

echo ""
echo "启动ngrok隧道（端口3002）..."
echo ""
echo "⚠️  获得URL后，请："
echo "1. 使用 node update-callback-url.js 更新配置"
echo "2. 重启后端服务"
echo ""
echo "========================================="

# 启动ngrok
ngrok http 3002