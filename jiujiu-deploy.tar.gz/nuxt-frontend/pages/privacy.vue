<template>
  <div class="privacy-page-bg">
    <!-- 顶部导航 -->
    <AppHeader />
    <div class="privacy-content">
      <div class="privacy-header">
        <div class="privacy-header-top">
          <img src="/images/logo.png" alt="logo" class="privacy-header-logo" />
          <div class="privacy-header-brand">凡图拉</div>
        </div>
        <div class="privacy-header-title">凡图拉平台隐私政策</div>
        <div class="privacy-header-en">Ventura Privacy Policy</div>
        <div class="privacy-header-desc">我们深知个人信息对您的重要性，并承诺依法收集、合理使用并保护您的信息安全</div>
      </div>
      <div class="privacy-body">
        <div class="privacy-col privacy-col-cn privacy-col-cn-main">
          <div class="privacy-overview-box privacy-overview-box-cn">
            <div class="privacy-overview-title">隐私政策概览</div>
            <div class="privacy-overview-desc">本政策适用于凡图拉网站（以下简称"本平台"）提供的所有服务。请您仔细阅读，特别是涉及限制、免责、信息使用规则等内容。</div>
          </div>
          
          <!-- 空行调整 -->
          <div class="privacy-spacer" style="height: 20px;"></div>
          
          <div class="privacy-section-title blue-title with-line">一、我们如何收集与使用信息</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            <div class="privacy-section-desc">1.1 为向您提供基础服务（如注册、登录、订单记录），我们可能收集以下信息：</div>
            <ul class="privacy-list blue-dot">
              <li>电子邮箱（用于注册、登录、接收验证码）</li>
              <li>登录时间、操作日志、浏览行为等匿名使用数据</li>
            </ul>
            
                      <!-- 空行调整 - 1.1和1.2之间，增加空行匹配英文版 -->
          <div class="privacy-spacer" style="height: 25px;"></div>
          
            <div class="privacy-section-highlight">1.2 本平台不会收集以下敏感个人信息：</div>
            <ul class="privacy-list blue-dot">
              <li>身份证信息</li>
              <li>手机号</li>
              <li>家庭住址</li>
              <li>面部特征</li>
              <li>支付密码</li>
            </ul>
          
          <!-- 空行调整 - 1.2和1.3之间 -->
          <div class="privacy-spacer" style="height: 25px;"></div>
            
            <div class="privacy-section-desc">1.3 我们使用这些信息仅限于：</div>
            <ul class="privacy-list blue-dot">
              <li>提供账户登录、信息校验等功能</li>
              <li>生成匿名使用统计，优化产品服务</li>
              <li>处理退款、售后等您主动发起的请求</li>
            </ul>
          </div>
          
          <!-- 空行调整 -->
          <div class="privacy-spacer" style="height: 25px;"></div>
          
          <div class="privacy-section-title blue-title with-line">二、Cookies 与本地存储</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            <div class="privacy-section-desc">2.1 我们可能使用 Cookies 或本地缓存技术，以便：</div>
            <ul class="privacy-list blue-dot">
              <li>记住登录状态</li>
              <li>简化页面操作流程</li>
              <li>分析访问行为，用于提升服务体验</li>
            </ul>
            
            <!-- 空行调整 - 2.1和2.2之间 -->
            <div class="privacy-spacer" style="height: 30px;"></div>
            
            <div class="privacy-section-desc">2.2 您可通过浏览器设置限制或清除 Cookie。</div>
          </div>
          
          <!-- 空行调整 - 第二章和第三章之间，中文版较短需要更多空行 -->
          <div class="privacy-spacer" style="height: 60px;"></div>
          
          <div class="privacy-section-title blue-title with-line">三、信息的共享、披露与转让</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            <span class="privacy-bold">3.1</span> 我们不会与任何第三方分享您的个人信息，除非：
            <ul class="privacy-list blue-dot">
              <li>经您本人同意</li>
              <li>为履行法律义务或政府机关相关请求</li>
              <li>为完成支付、发货等必要环节时，最小范围信息与合作机构协作</li>
            </ul>
            
            <!-- 空行调整 -->
            <div class="privacy-spacer" style="height: 25px;"></div>
            
            <div class="privacy-highlight-box">
              <span class="privacy-bold">3.2</span> 我们不会将您的信息转让或出售。
            </div>
            
            <!-- 空行调整 -->
            <div class="privacy-spacer" style="height: 20px;"></div>
            
            <span class="privacy-bold">3.3</span> 若将来发生平台合并、收购或资产重组，我们会告知您并保障个人信息继续受到本政策保护。
          </div>
          
          <!-- 空行调整 - 第三章和第四章之间 -->
          <div class="privacy-spacer" style="height: 40px;"></div>
          
          <div class="privacy-section-title blue-title with-line">四、您对信息的控制权</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            <span class="privacy-bold">4.1</span> 您有权访问、修改或注销您的账户<br />
            <span class="privacy-bold">4.2</span> 如您注销账户，平台将在法律允许范围内清除相关数据<br />
            <span class="privacy-bold">4.3</span> 如您需导出或删除信息，可通过客服邮箱提出申请
          </div>
          
          <!-- 空行调整 - 第四章和第五章之间，中文版较短需要更多空行 -->
          <div class="privacy-spacer" style="height: 50px;"></div>
          
          <div class="privacy-section-title blue-title with-line">五、信息安全与存储</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            <span class="privacy-bold">5.1</span> 我们使用多种手段保护您的数据，包括：
            <ul class="privacy-list blue-dot">
              <li>加密存储、权限分级控制</li>
              <li>定期审计与访问监控</li>
              <li>员工安全培训与操作规范</li>
            </ul>
            
            <!-- 空行调整 -->
            <div class="privacy-spacer" style="height: 25px;"></div>
            
            <div class="privacy-highlight-box">
              <span class="privacy-bold">5.2</span> 您的数据将被保存在中华人民共和国境内。
            </div>
          </div>
          
          <!-- 空行调整 - 第五章和第六章之间 -->
          <div class="privacy-spacer" style="height: 40px;"></div>
          
          <div class="privacy-section-title blue-title with-line">6. 未成年人保护</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            本平台不面向14周岁以下未成年人提供服务。若您为14周岁以下用户，应在监护人同意与指导下使用服务。
          </div>
          
          <!-- 空行调整 - 第六章和第七章之间，中文版内容较短 -->
          <div class="privacy-spacer" style="height: 60px;"></div>
          
          <div class="privacy-section-title blue-title with-line">7. 本政策的变更</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            我们可能会不定期更新本政策，变更将在网站公告或登录页提示。更新后继续使用即视为您接受修改内容。
          </div>
          
          <!-- 空行调整 - 第七章后，中文版较短需要补偿高度 -->
          <div class="privacy-spacer" style="height: 55px;"></div>
          
          <div class="privacy-contact-card">
            <div class="privacy-contact-title">联系我们</div>
            <div class="privacy-contact-desc">如您对本隐私政策有任何疑问、投诉或建议，请通过以下方式联系：</div>
            <div class="privacy-contact-mail">support@fantura.com</div>
            <div class="privacy-contact-tip">我们将在3个工作日内回复您的咨询</div>
          </div>
          
          <!-- 空行调整 - 联系我们和附录之间的间距 -->
          <div class="privacy-spacer" style="height: 15px;"></div>
          
          <div class="privacy-section-appendix">
            <span class="privacy-appendix-title">附：英文版说明</span><br />
            <span class="privacy-appendix-desc">本隐私政策提供英文版本（Ventura Privacy Policy）供参考，如中英文版本存在任何歧义或不一致，应以中文版为准。</span>
          </div>
        </div>
        <div class="privacy-col privacy-col-en privacy-col-en-main">
          <div class="privacy-overview-box privacy-overview-box-en">
            <div class="privacy-overview-title">Ventura Privacy Policy</div>
            <div class="privacy-overview-desc">Welcome to Ventura! We value your privacy and are committed to protecting your data in compliance with applicable laws. This policy applies to all services provided by Ventura's website ("the platform"). Please read carefully.</div>
          </div>
          <div class="privacy-en-section-title">1.Information We Collect and Use</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            1.1 In order to provide you with basic services (such as registration, login, and order records), we may collect the following information:
            <ul class="privacy-list blue-dot">
              <li>Email address (used for account registration and login)</li>
              <li>Anonymous usage data: login time, click behavior, browsingslogs</li>
            </ul>
            <div class="privacy-en-highlight">1.2 The Platform will not collect the following sensitive personal information：</div>
            <ul class="privacy-list blue-dot">
              <li>ID information</li>
              <li>Mobile phone number</li>
              <li>Home address</li>
              <li>Facial features</li>
              <li>Payment password</li>
            </ul>
            1.3 We use this information only for:
            <ul class="privacy-list blue-dot">
              <li>Provide account login and information verification functions</li>
              <li>Generate anonymous usage statistics to optimize products and services</li>
              <li>Handle your unsolicited requests such as refunds, after-sales, etc</li>
            </ul>
          </div>
          <div class="privacy-en-section-title">2.Cookies and Local Storage</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            2.1 We may use cookies or local caching technologies in order to:
            <ul class="privacy-list blue-dot">
              <li>Remember the sign-in status</li>
              <li>Simplify the process of page operations</li>
              <li>Analyze access behavior to improve the service experience</li>
            </ul>
            2.2 You can restrict or clear cookies through your browser settings.
          </div>
          <div class="privacy-en-section-title">3.Sharing, Disclosure and Transfer of Information</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            3.1 We will not share your personal information with any third parties unless:
            <ul class="privacy-list blue-dot">
              <li>With your consent</li>
              <li>To comply with a legal obligation or to comply with a request from a government agency</li>
              <li>In order to complete the necessary links such as payment and delivery, we will cooperate with partner organizations for the minimum range of information</li>
            </ul>
            <div class="privacy-en-highlight-box">
              <span class="privacy-en-bold">3.2 We do not transfer or sell your information.</span>
            </div>
            3.3 In the event of a merger, acquisition or asset restructuring of the Platform in the future, we will inform you and ensure that your personal information continues to be protected by this Policy.
          </div>
          <div class="privacy-en-section-title">4. Your Control over Information</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            4.1 You have the right to access, modify or cancel your account<br />
            4.2 If you cancel your account, the Platform will clear the relevant data to the extent permitted by law<br />
            4.3 If you need to export or delete information, you can submit a request through the customer service email
          </div>
          <div class="privacy-en-section-title">5. Information Security and Storage</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            5.1 We use a variety of means to protect your data, including:
            <ul class="privacy-list blue-dot">
              <li>Encrypted storage and hierarchical permission control</li>
              <li>Regular audits and access monitoring</li>
              <li>Employee safety training and operation specifications</li>
            </ul>
            <div class="privacy-en-highlight-box">
              <span class="privacy-en-bold">5.2 Your data will be stored within the territory of the People's Republic of China.</span>
            </div>
          </div>
          <div class="privacy-en-section-title">6. Protection of Minors</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            The Platform does not provide services to minors under the age of 14. If you are a user under the age of 14, you should use the service with the consent and guidance of your guardian.
          </div>
          <div class="privacy-en-section-title">7. Changes to this Policy</div>
          <div class="privacy-section-line"></div>
          <div class="privacy-section">
            We may update this Policy from time to time, and changes will be announced on the website or on the landing page. If you continue to use it after the update, you will be deemed to have accepted the modifications.
          </div>
          <div class="privacy-en-contact-card">
            <div class="privacy-en-contact-title">Contact us</div>
            <div class="privacy-en-contact-desc">If you have any questions, complaints or suggestions about this Privacy Policy, please contact us at:</div>
            <div class="privacy-en-contact-mail">support@fantura.com</div>
            <div class="privacy-en-contact-tip">We will respond to your inquiry within 3 working days</div>
          </div>
          <div class="privacy-en-appendix">
            <span class="privacy-en-appendix-title">Attached: English version description</span><br />
            <span class="privacy-en-appendix-desc">The English version of this Privacy Policy (Ventura Privacy Policy) is provided for reference, if there is any ambiguity or inconsistency between the Chinese and English versions, the Chinese version shall prevail</span>
          </div>
        </div>
      </div>
    </div>
    <AppFooter />

    <!-- 登录注册弹窗 -->
    <LoginRegisterModal :visible="modal.showLogin" @close="modal.closeLogin()" />
  </div>
</template>

<script setup lang="ts">
import AppHeader from '@/components/AppHeader.vue'
import AppFooter from '@/components/AppFooter.vue'
import { useModalStore } from '@/stores/modal'

const modal = useModalStore()
</script>

<style scoped>
.privacy-page-bg {
  width: 100vw;
  height: auto;
  min-height: 100vh;
  border-radius: 0px;
  margin: 0 auto;
  background: #f8faff;
  display: flex;
  flex-direction: column;
}
.privacy-content {
  flex: 1;
  max-width: 1400px;
  width: 90vw;
  margin: 48px auto 48px auto;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.04);
  padding: 32px 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.privacy-header {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin-top: 32px;
  margin-bottom: 32px;
}
.privacy-header-top {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
}
.privacy-header-logo {
  width: 60px;
  height: 60px;
  border-radius: 50%;
}
.privacy-header-brand {
  font-size: 28px;
  font-weight: bold;
  color: #2583f6;
  margin: 0 0 6px 0;
  letter-spacing: 1px;
}
.privacy-header-title {
  font-size: 24px;
  font-weight: bold;
  color: #222;
  margin-bottom: 6px;
  text-align: center;
}
.privacy-header-en {
  font-size: 16px;
  color: #888;
  margin-bottom: 8px;
  text-align: center;
}
.privacy-header-desc {
  font-size: 14px;
  color: #888;
  margin-bottom: 0;
  line-height: 1.4;
  text-align: center;
}
.privacy-body {
  display: flex;
  gap: 32px;
  align-items: flex-start;
  justify-content: center;
  width: 100%;
  margin: 0 auto;
  max-width: 1300px;
}
.privacy-col {
  flex: 1;
  background: #f8f9ff;
  border-radius: 12px;
  padding: 0 0 32px 0;
  box-shadow: 0 2px 8px rgba(59,130,246,0.04);
  font-size: 15px;
  color: #222;
  display: flex;
  flex-direction: column;
}
.privacy-col-cn {
  margin-right: 0;
}
.privacy-col-en {
  margin-left: 0;
}
.privacy-col-cn-main,
.privacy-col-en-main {
  width: 42vw;
  max-width: 600px;
  min-width: 400px;
  min-height: 800px;
  height: auto;
  border-radius: 8px;
  box-sizing: border-box;
  padding: 24px;
  background: #fff;
  margin: 0;
  display: flex;
  flex-direction: column;
  position: relative;
  border: 1px solid #e5e5e5;
}
.privacy-section-title,
.privacy-en-section-title {
  color: #2583f6;
  font-weight: bold;
  font-size: 22px;
  border-left: 4px solid #2583f6;
  padding-left: 8px;
  margin-top: 32px;
  margin-bottom: 0;
  line-height: 79px;
  font-family: 'Noto Sans SC-Black', 'Noto Sans Black', 'Noto Sans', 'Noto Sans SC', Arial, sans-serif;
  height: 54px;
  display: flex;
  align-items: center;
}
.privacy-section {
  margin-bottom: 16px;
  line-height: 1.9;
}
.privacy-highlight {
  background: #eaf6ff;
  color: #2563EB;
  padding: 2px 6px;
  border-radius: 6px;
}
.privacy-contact {
  color: #2563EB;
  font-weight: bold;
  font-size: 16px;
}
.privacy-section-tip {
  background: #f6faff;
  color: #888;
  border-radius: 8px;
  padding: 10px 16px;
  margin-top: 18px;
  font-size: 14px;
}
.privacy-list {
  margin: 8px 0 16px 24px;
  padding: 0;
  list-style: disc;
  color: #222;
  font-size: 18px;
}
.privacy-section-desc {
  margin-bottom: 2px;
  color: #222;
  font-size: 18px;
}
.privacy-section-highlight {
  color: #2583f6;
  font-weight: bold;
  margin: 10px 0 2px 0;
  font-size: 18px;
}
.privacy-section-title.with-line {
  position: relative;
  margin-bottom: 0;
}
.privacy-section-line {
  width: 100%;
  height: 2px;
  background: #e3f0ff;
  margin: 8px 0 18px 0;
  border-radius: 2px;
}
.privacy-overview-box-cn,
.privacy-overview-box-en {
  width: 100%;
  height: auto;
  min-height: 120px;
  background: #F8FAFF;
  border-radius: 8px;
  border: 1px solid #EAEAEA;
  box-sizing: border-box;
  margin-bottom: 36px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 24px;
}
.privacy-overview-title {
  color: #2583f6;
  font-size: 22px;
  font-weight: bold;
  margin-bottom: 8px;
}
.privacy-overview-desc {
  color: #444;
  font-size: 16px;
  line-height: 1.8;
}
.blue-title {
  color: #2583f6;
  font-weight: bold;
  font-size: 18px;
  border-left: 4px solid #2583f6;
  padding-left: 8px;
  margin-top: 32px;
  margin-bottom: 12px;
}
.privacy-bold {
  font-weight: bold;
  color: #222;
}
.privacy-list.blue-dot {
  list-style: disc inside;
  color: #2583f6;
  margin-left: 18px;
  margin-bottom: 8px;
}
.privacy-list.blue-dot li {
  color: #222;
  margin-bottom: 2px;
  position: relative;
}
.privacy-list.blue-dot li::marker {
  color: #2583f6;
  font-size: 15px;
}
.privacy-highlight-box,
.privacy-en-highlight-box {
  width: 100%;
  height: auto;
  min-height: 60px;
  background: #E6F7FF;
  border-radius: 0px 8px 8px 0px;
  border-left: 4px solid #1890FF;
  border-top: none;
  border-right: none;
  border-bottom: none;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  margin: 24px 0 24px 0;
  color: #222;
  font-size: 16px;
  font-weight: normal;
  line-height: 1.8;
  padding: 16px 24px;
}
.privacy-section-title.blue-title.with-line {
  color: #2583f6;
  font-weight: bold;
  font-size: 18px;
  border-left: 4px solid #2583f6;
  padding-left: 8px;
  margin-top: 32px;
  margin-bottom: 0;
  line-height: 1.7;
}
.privacy-section-line {
  width: 100%;
  height: 2px;
  background: #e3f0ff;
  margin: 8px 0 18px 0;
  border-radius: 2px;
}
.privacy-contact-card,
.privacy-en-contact-card {
  width: 100%;
  height: auto;
  min-height: 200px;
  background: #F8FAFF;
  border-radius: 15px;
  box-sizing: border-box;
  padding: 32px 24px;
  margin: 48px 0 24px 0;
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
.privacy-contact-title,
.privacy-en-contact-title {
  color: #2583f6;
  font-size: 22px;
  font-weight: bold;
  margin-bottom: 12px;
}
.privacy-contact-desc,
.privacy-en-contact-desc {
  color: #666;
  font-size: 16px;
  margin-bottom: 18px;
}
.privacy-contact-mail,
.privacy-en-contact-mail {
  color: #2583f6;
  font-size: 22px;
  font-weight: bold;
  margin-bottom: 10px;
}
.privacy-contact-tip,
.privacy-en-contact-tip {
  color: #888;
  font-size: 15px;
  margin-bottom: 0;
}
.privacy-section-appendix,
.privacy-en-appendix {
  width: 100%;
  height: auto;
  min-height: 100px;
  background: #F8FAFF;
  border-radius: 12px;
  border: 1px solid #1890FF;
  box-sizing: border-box;
  padding: 24px;
  margin-top: 24px;
  color: #666;
  font-size: 16px;
  line-height: 1.8;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.privacy-appendix-title,
.privacy-en-appendix-title {
  color: #2583f6;
  font-weight: bold;
  font-size: 15px;
}
.privacy-appendix-desc,
.privacy-en-appendix-desc {
  color: #666;
  font-size: 15px;
}
.privacy-section,
.privacy-list,
.privacy-section-desc {
  font-family: 'Noto Sans SC', 'Noto Sans', 'Noto Sans SC-Regular', 'Noto Sans-Regular', Arial, sans-serif;
  font-weight: 400;
  font-size: 16px;
  line-height: 39px;
}
.privacy-section-title,
.privacy-en-section-title {
  font-family: 'Noto Sans SC-Black', 'Noto Sans Black', 'Noto Sans', 'Noto Sans SC', Arial, sans-serif;
  font-weight: 900;
  font-size: 22px;
  line-height: 79px;
}
.privacy-section-subtitle,
.privacy-en-section-subtitle {
  font-family: 'Noto Sans SC-Regular', 'Noto Sans-Regular', 'Noto Sans', Arial, sans-serif;
  font-weight: 400;
  font-size: 16px;
  line-height: 52px;
}
/* 一级标题透明框 */
.privacy-title-box,
.privacy-en-title-box {
  width: 100%;
  height: auto;
  min-height: 54px;
  border-radius: 8px;
  border: 2px solid #E6F7FF;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  margin-bottom: 18px;
  background: transparent;
  padding: 12px;
}
/* 二级标题透明框 */
.privacy-subtitle-box,
.privacy-en-subtitle-box {
  width: 100%;
  height: auto;
  min-height: 29px;
  border-radius: 4px;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  margin-bottom: 12px;
  background: transparent;
  padding: 8px;
}
/* 正文透明框 */
.privacy-paragraph-box,
.privacy-en-paragraph-box {
  width: 100%;
  height: auto;
  min-height: 27px;
  border-radius: 4px;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  margin-bottom: 8px;
  background: transparent;
  padding: 6px;
}
/* 各标题整块板块尺寸 */
.privacy-section-block-1,
.privacy-section-block-2,
.privacy-section-block-3,
.privacy-section-block-4,
.privacy-section-block-5,
.privacy-section-block-6,
.privacy-section-block-7 {
  width: 100%;
  height: auto;
  border-radius: 8px;
  box-sizing: border-box;
  padding: 16px;
  margin-bottom: 16px;
}
/* 联系我们板块 */
/* 版本说明板块 */

/* 空行调整样式 */
.privacy-spacer {
  width: 100%;
  display: block;
  background: transparent;
}

</style> 