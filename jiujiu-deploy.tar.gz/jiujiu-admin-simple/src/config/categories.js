// 商品分类配置 - 频道会员类型
export const categories = [
  {
    id: 1640024168227504129,
    name: '视频音乐',
    sortOrder: 3
  },
  {
    id: 1640024250796572673,
    name: 'Vtuber',
    sortOrder: 4
  },
  {
    id: 1640027790516518913,
    name: '代充代付',
    sortOrder: 8
  },
  {
    id: 1640027968497614849,
    name: '游戏',
    sortOrder: 9
  },
  {
    id: 1640028021496840194,
    name: '卡劵',
    sortOrder: 10
  },
  {
    id: 1690673796101869569,
    name: '福利社',
    sortOrder: 10
  }
];

export default categories;